<?php
// switch
$_['text_coffecrm_on']                           = 'Pegar CoffeeShopCrm';
$_['text_coffecrm_off']                           = 'Prender off CoffeeShopCrm';



