<?php
// Heading
$_['heading_title']                = 'Devoluciones del Cliente';


// titles
$_['t_return_id'] = 'ID devolución';
$_['t_date_added'] = 'Fecha generada';
$_['t_order_id'] = 'Iid de Orden';
$_['t_product_id'] = 'id de Producto';
$_['t_product'] = 'Productos';
$_['t_model'] = 'Modelo';
$_['t_quantity'] = 'Cantidad';
$_['t_opened'] = 'Abierto';
$_['t_reason'] = 'Razón de devolución';
$_['t_raction'] = 'Modificar devolución';
$_['t_status'] = 'Estado de Devolución';
$_['t_comment'] = 'Comentario';
$_['t_action'] = 'Acción';


// content
$_['c_opened'] = 'si';
$_['c_closed'] = 'no';
$_['c_edit'] = 'editar';