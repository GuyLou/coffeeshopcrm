<?php

// titles
$_['tstage'] = 'Fase';
$_['tpast_due_dates'] = 'Fechas de vencimiento pasados';
$_['tcurrent_due_dates'] = 'Fechas de vencimiento actuales';
$_['tfuture_due_dates'] = 'Fechas de vencimiento futuros';
$_['text_no_results '] = 'sin resultados !';

$_['order'] = 'Ordenes';
$_['sale'] = 'Ventas';
$_['service'] = 'Servicios';

$_['cr-'] = 'CR - ';

