<?php
// Heading
$_['heading_title_sale']                           = 'Ventas';
$_['heading_title_service']                           = 'Servicios';

// Text
$_['text_list']                               = 'Lista de Ordenes';
$_['text_missing']                            = 'Faltas Ordenes';
$_['text_confirm'] = 'Confirmar';
$_['text_missing'] = 'falta texto';

// Buttons
$_['btn_dashboard'] = 'Tablero';
$_['btn_search'] = 'Buscar';
$_['btn_home'] = 'Inicio';
$_['btn_customer'] = 'Detalles del clientes';
$_['btn_close'] = 'Cerrar';
$_['btn_cr'] = 'Customer Relationships';