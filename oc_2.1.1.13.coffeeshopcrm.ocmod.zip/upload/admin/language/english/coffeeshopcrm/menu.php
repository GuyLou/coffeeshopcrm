<?php
// switch
$_['text_coffecrm_on']                           = 'Turn on CoffeeShopCrm';
$_['text_coffecrm_off']                           = 'Turn off CoffeeShopCrm';



