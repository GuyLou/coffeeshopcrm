<?php
// Heading
$_['heading_title']                = 'Customer Returns';


// titles
$_['t_return_id'] = 'Return id';
$_['t_date_added'] = 'Date added';
$_['t_order_id'] = 'Order id';
$_['t_product_id'] = 'Product id';
$_['t_product'] = 'Product';
$_['t_model'] = 'Model';
$_['t_quantity'] = 'Quantity';
$_['t_opened'] = 'Opened';
$_['t_reason'] = 'Return reason';
$_['t_raction'] = 'Return action';
$_['t_status'] = 'Return status';
$_['t_comment'] = 'Comment';
$_['t_action'] = 'Action';


// content
$_['c_opened'] = 'yes';
$_['c_closed'] = 'no';
$_['c_edit'] = 'edit';