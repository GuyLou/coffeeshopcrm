<?php

// titles
$_['tstage'] = 'Stage';
$_['tpast_due_dates'] = 'Past Due Dates';
$_['tcurrent_due_dates'] = 'Current Due Dates';
$_['tfuture_due_dates'] = 'Future Due Dates';
$_['text_no_results '] = 'No results !';

$_['order'] = 'Orders';
$_['sale'] = 'Sales';
$_['service'] = 'Services';

$_['cr-'] = 'CR - ';

