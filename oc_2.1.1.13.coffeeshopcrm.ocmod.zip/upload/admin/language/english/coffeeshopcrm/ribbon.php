<?php
// Heading
$_['heading_title_sale']                           = 'Sales';
$_['heading_title_service']                           = 'Services';

// Text
$_['text_list']                               = 'Order List';
$_['text_missing']                            = 'Missing Orders';
$_['text_confirm'] = 'Confirm';
$_['text_missing'] = 'text_missing';

// Buttons
$_['btn_dashboard'] = 'Dashboard';
$_['btn_search'] = 'Search';
$_['btn_home'] = 'Home';
$_['btn_customer'] = 'Customer details';
$_['btn_close'] = 'Close';
$_['btn_cr'] = 'Customer Relationships';