<?php

// titles
$_['tstage'] = 'Стадия';
$_['tpast_due_dates'] = 'Просроченные даты';
$_['tcurrent_due_dates'] = 'Текущие сроки оплаты';
$_['tfuture_due_dates'] = 'Будущие сроки оплаты';
$_['text_no_results '] = 'Отсутствие результатов!';

$_['order'] = 'Заказы';
$_['sale'] = 'продажи';
$_['service'] = 'услуги';

$_['cr-'] = 'CR - ';

