<?php
// Heading
$_['heading_title_sale']                           = 'Продажи';
$_['heading_title_service']                           = 'обслуживание';

// Text
$_['text_list']                               = 'Список заказа';
$_['text_missing']                            = 'Пропавшие заказы';
$_['text_confirm'] = 'подтвердить';
$_['text_missing'] = 'отсытствия текста';

// Buttons
$_['btn_dashboard'] = 'Панель управления';
$_['btn_search'] = 'Поиск';
$_['btn_home'] = 'Главная';
$_['btn_customer'] = 'реквизиты клиента';
$_['btn_close'] = 'закрывать';
$_['btn_cr'] = 'Customer Relationships';