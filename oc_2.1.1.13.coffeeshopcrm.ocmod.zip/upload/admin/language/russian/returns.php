<?php
// Heading
$_['heading_title']                = 'Возвращает Заказчика';


// titles
$_['t_return_id'] = 'ID возврата';
$_['t_date_added'] = 'Дата добавления';
$_['t_order_id'] = 'ID заказа';
$_['t_product_id'] = 'ID Товар';
$_['t_product'] = 'Товар';
$_['t_model'] = 'Артикул';
$_['t_quantity'] = 'Количество';
$_['t_opened'] = 'Открытый';
$_['t_reason'] = 'Причина возврата';
$_['t_raction'] = 'Действия Возврата';
$_['t_status'] = 'Статус возврата';
$_['t_comment'] = 'Комментарий';
$_['t_action'] = 'Действие';


// content
$_['c_opened'] = 'да';
$_['c_closed'] = 'нет';
$_['c_edit'] = 'Редактировать';