<?php
// switch
$_['text_coffecrm_on']                           = 'Включить CoffeeShopCrm';
$_['text_coffecrm_off']                           = 'Выключить CoffeeShopCrm';



